import 'package:flutter/material.dart';

const Map<String, IconData> icons = {
  "topic": Icons.topic,
  "abc": Icons.abc,
  "code": Icons.code,
  "bug_report": Icons.bug_report,
  "lightbulb": Icons.lightbulb,
  "summarize": Icons.summarize,
  "compare": Icons.compare,
  "quiz": Icons.quiz,
};

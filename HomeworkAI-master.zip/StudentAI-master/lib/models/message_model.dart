class MessageModel {
  String text;
  String sender;

  MessageModel({required this.text, required this.sender});
}
